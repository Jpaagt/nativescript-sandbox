"use strict";
var main_view_model_1 = require("./main-view-model");
var tab_view_1 = require("ui/tab-view");
var mainViewModel = new main_view_model_1.MainViewModel();
function onNavigatingTo(args) {
    console.log("MainPage::onNavigatingTo");
    var page = args.object;
    page.bindingContext = mainViewModel;
}
exports.onNavigatingTo = onNavigatingTo;
function onLoaded(args) {
    console.log("Main page loading...");
    var page = args.object;
    var tabView = page.getViewById("tabView");
    tabView.on(tab_view_1.TabView.selectedIndexChangedEvent, onTabChange);
    mainViewModel.selectedIndex = tabView.selectedIndex;
    console.log("Main page loaded");
}
exports.onLoaded = onLoaded;
function onTabChange(evt) {
    console.log("Old index:" + evt.oldIndex);
    console.log("New index:" + evt.newIndex);
    mainViewModel.selectedIndex = evt.newIndex;
}
//# sourceMappingURL=main-page.js.map