"use strict";
var observable_1 = require("data/observable");
var MenuViewModel = (function (_super) {
    __extends(MenuViewModel, _super);
    function MenuViewModel() {
        _super.call(this);
        this.loaded = false;
        this.set("title", "Menu");
    }
    MenuViewModel.prototype.load = function () {
        var _this = this;
        console.log("Loading MenuViewModel...");
        if (!this.loaded && !this.isLoading) {
            this.set("isLoading", true);
            console.log("MenuViewModel loading for the first time...");
            setTimeout(function () {
                _this.set("entry1", "Entry 1");
                _this.set("entry2", "Entry 2");
                _this.set("entry3", "Entry 3");
                _this.set("isLoading", false);
                _this.set("loaded", true);
                console.log("MenuViewModel loaded");
            }, 3000);
        }
        else {
            console.log("MenuViewModel already loaded");
        }
    };
    MenuViewModel.prototype.unload = function () {
        console.log("Menu unloaded");
    };
    return MenuViewModel;
}(observable_1.Observable));
exports.MenuViewModel = MenuViewModel;
//# sourceMappingURL=menu-view-model.js.map