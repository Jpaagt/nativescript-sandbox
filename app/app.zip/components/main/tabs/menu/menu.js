"use strict";
var observable_1 = require("data/observable");
var stackLayout;
var menuViewModel;
var view;
function onLoad(args) {
    console.log("Menu loading...");
    stackLayout = args.object;
    view = stackLayout.getViewById("menuView");
    menuViewModel = stackLayout.bindingContext;
    menuViewModel.on(observable_1.Observable.propertyChangeEvent, onPropertyChangeEvent);
    console.log("Menu loaded");
}
exports.onLoad = onLoad;
function onPropertyChangeEvent(evt) {
    console.log(evt.propertyName + ": " + evt.value);
    if (evt.propertyName === "loaded") {
        onModelLoaded();
    }
}
function onModelLoaded() {
    console.log("onModelLoaded");
    view.animate({
        opacity: 1,
        duration: 1000
    });
}
//# sourceMappingURL=menu.js.map