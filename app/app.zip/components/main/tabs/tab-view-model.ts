export interface TabViewModel {

  load(): void;

  unload(): void;
  
}