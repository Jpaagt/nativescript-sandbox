"use strict";
function onNavigatingTo(args) {
    console.log("Main::onNavigatingTo");
}
exports.onNavigatingTo = onNavigatingTo;
function onLoaded(args) {
    console.log("Main::onLoaded");
}
exports.onLoaded = onLoaded;
//# sourceMappingURL=main.js.map