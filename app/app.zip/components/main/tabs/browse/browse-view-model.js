"use strict";
var observable_1 = require("data/observable");
var BrowseViewModel = (function (_super) {
    __extends(BrowseViewModel, _super);
    function BrowseViewModel() {
        _super.apply(this, arguments);
    }
    BrowseViewModel.prototype.load = function () {
        console.log("Browse loaded");
    };
    BrowseViewModel.prototype.unload = function () {
        console.log("Browse unloaded");
    };
    return BrowseViewModel;
}(observable_1.Observable));
exports.BrowseViewModel = BrowseViewModel;
//# sourceMappingURL=browse-view-model.js.map