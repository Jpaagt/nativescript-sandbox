"use strict";
var observable_1 = require("data/observable");
var browse_view_model_1 = require("./tabs/browse/browse-view-model");
var menu_view_model_1 = require("./tabs/menu/menu-view-model");
var MainViewModel = (function (_super) {
    __extends(MainViewModel, _super);
    function MainViewModel() {
        _super.call(this);
        this.browseViewModel = new browse_view_model_1.BrowseViewModel();
        this.menuViewModel = new menu_view_model_1.MenuViewModel();
        this.tabs = [
            this.menuViewModel,
            this.browseViewModel
        ];
        this.tabIndex = -1;
        this.set("title", "Main");
    }
    Object.defineProperty(MainViewModel.prototype, "selectedIndex", {
        get: function () {
            return this.tabIndex;
        },
        set: function (index) {
            console.log("Selected index " + index);
            if (index >= 0 && index < this.tabs.length && this.tabIndex !== index) {
                if (this.tabIndex >= 0 && this.tabIndex < this.tabs.length) {
                    this.tabs[this.tabIndex].unload();
                }
                this.tabIndex = index;
                this.tabs[index].load();
            }
        },
        enumerable: true,
        configurable: true
    });
    return MainViewModel;
}(observable_1.Observable));
exports.MainViewModel = MainViewModel;
//# sourceMappingURL=main-view-model.js.map