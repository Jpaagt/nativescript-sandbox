"use strict";
var application = require("application");
application.start({ moduleName: "components/main/main-page" });
//# sourceMappingURL=app.js.map