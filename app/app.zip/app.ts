import application = require("application");
application.start({ moduleName: "components/main/main-page" });
